package ec.espe.edu.HealthKeeper.Team3.controller;

import ec.espe.edu.HealthKeeper.Team3.view.Menu;

/**
 *
 * @author Team 3
 */
public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.showMenu();  
    }
}
