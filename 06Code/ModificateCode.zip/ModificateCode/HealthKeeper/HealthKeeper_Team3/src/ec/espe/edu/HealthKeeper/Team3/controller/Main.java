package ec.espe.edu.HealthKeeper.Team3.controller;

import ec.espe.edu.HealthKeeper.Team3.view.LoginFrame; // Importa tu LoginFrame
import ec.espe.edu.HealthKeeper.Team3.model.MongoDBDataManager; // Importa tu MongoDBDataManager

import javax.swing.JOptionPane; // Necesario para el mensaje de error de conexión

/**
 *
 * @author Team 3
 */
public class Main {
    // Declaramos una instancia estática de MongoDBDataManager para que sea accesible
    // desde cualquier parte de la aplicación.
    public static MongoDBDataManager mongoDataManager;

    public static void main(String[] args) {
        // Inicializa y conecta el gestor de la base de datos
        // La conexión se maneja dentro del constructor de MongoDBDataManager
        mongoDataManager = new MongoDBDataManager();

        // Puedes añadir una verificación simple para ver si la conexión se estableció
        // Por ejemplo, intentando obtener una colección. Si hay un error, el constructor ya lo imprime.
        try {
            // Intenta obtener una colección para verificar la conexión.
            // Si la conexión falla en el constructor, 'database' será null.
            if (mongoDataManager.getCollection("testConnection") == null) {
                JOptionPane.showMessageDialog(null, 
                    "Error crítico: No se pudo establecer conexión con MongoDB. La aplicación se cerrará.", 
                    "Error de Conexión a la Base de Datos", 
                    JOptionPane.ERROR_MESSAGE);
                System.exit(1); // Sale de la aplicación si no hay conexión
            }
        } catch (Exception e) {
            // Esto captura cualquier otra excepción durante la verificación de la colección.
            JOptionPane.showMessageDialog(null, 
                "Error al verificar la conexión a MongoDB: " + e.getMessage() + ". La aplicación se cerrará.", 
                "Error de Verificación", 
                JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }


        /* Crea y muestra el formulario de Login */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginFrame().setVisible(true); // Lanza tu ventana de Login
            }
        });

        // NOTA IMPORTANTE: No cierres la conexión aquí (mongoDataManager.closeConnection();)
        // La conexión a MongoDB debe permanecer abierta mientras la aplicación esté en uso.
        // La conexión se debe cerrar cuando la aplicación se esté cerrando.
        // Esto se hará añadiendo un WindowListener al JFrame principal (MenuFrame).
    }
}
